from pathlib import Path
import os.path
from os import path
import shutil


#base_path = Path(__file__).parent
#file_path = (base_path / "../Student Example/student.txt").resolve()

base_path=os.path.dirname(os.path.realpath(__file__))
file_path=os.path.join(base_path, 'student.txt')

#adding file entries to a list
a=[]
with open(file_path) as f:
    
    for z in f:
     #print(z.split(',')) 
     a.append( z.strip().split(","))
#print(a)
f.close()

#Creating dictionary with rollnum,studname etc as keys using list
dict = {}
for i in range(len(a)):
    if i == 0:
        for j in a[i]:
            dict[j] = []
           
    else :
        for j in range(len(a[i])):
            #print(j)
            dict[a[0][j]].append( a[i][j])
            #print(dict[a[0][j]])


#reading tempstud.txt file
#file_path = (base_path / "../Student Example/tempstud.txt").resolve()
file_path=os.path.join(base_path, 'tempstud.txt')
temp=''
with open(file_path) as f:
    temp=f.read()
#print(temp)
f.close()    

#finding no.of entries in student.txt
ln=len(dict['<Rollno>'])
print('Number of entries in student.txt:'+ str(ln))


path1 = os.path.join(base_path, 'Files')
if path.exists(path1):
    shutil.rmtree(path1)
    os.mkdir(path1)
else:
    os.mkdir(path1)  

Total_marks={}

#iterating over each key's one value at a time
for i in range(ln):
    temp_new=temp
    for keys in dict:
      temp_new=temp_new.replace(keys,dict[keys][i].strip()) 
    #print(temp_new)  
    filename=dict['<StudName>'][i].strip()+'.'+dict['<Rollno>'][i].strip()+'.txt'
    filename=os.path.join(path1, filename)
    rollnum=int(dict['<Rollno>'][i].strip())
    mark=int(dict['<Marks>'][i].strip())
    
    if path.exists(filename):

        found=0 #to check duplicate entry
        f=open(filename,"r") 
        for x in f:
           if x.strip() == temp_new.strip():
              found=1
        f.close()

    #find total marks
    if filename in Total_marks:
        if found == 0:

            Total_marks[filename]=Total_marks[filename] + mark
    else:
        Total_marks[filename]= mark
    
    #creating files
    #print('Filename:'+filename)
    if path.exists(filename):
        
        if found ==0:
            f=open(filename,"a")
            f.write("\n")
            f.write( temp_new )
            f.close()
           
    else:
        f = open(filename,"w")
        f.write( temp_new )
        f.close()

#inserting total marks 
for key in Total_marks:
    f=open(key,"a")
    f.write("\n\t\t\t\t")
    f.write("Total:"+ str(Total_marks[key]))
    f.close()
    print(key+' is successfully created')

   





  
    
